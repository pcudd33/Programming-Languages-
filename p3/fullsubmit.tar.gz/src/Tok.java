public enum Tok{
    PLUS,
    MINUS,
    DIVIDE,
    TIMES,
    LPAREN,
    RPAREN,
    COMMA,
    IDENT,
    INT,
    AT,
    EQUALS,
    ASSIGN,
    CLASS,              //case insesative
    COLON,
    DOT,
    ELSE,               //case insesative
    FALSE,              //case insesative
    IF,                 //case insesative
    ISVOID,             //case insesative
    LBRACE,
    LBRACKET,
    LET,                //case insesative
    LT,
    LTE,
    NEW,                //case insesative
    NOT,
    RBRACE,
    RBRACKET,
    SEMI,
    STRING,
    TRUE,               //case insesative
    UMINUS,
    WHILE              //case insesative


}