Within the P2.sl file holds implementation of a depth first search within it. The way me and caleb chose to implement 
this series of functions was recursively but also separated into smaller helper functions that allowed for the program
to be split up into readable chunks. Within all of these functions we used the provided List implementation and also used
the cons and ArrayList implementations to construct a series of list and arrays to create the graph and all node and neighbor
nodes. The way me and Caleb chose to do this allowed for us to store the Graph within an arraylist that contains ndoes 
witchin in turn are lists themsleves allowing us to have a large arraylist that can point from one node to another and so on. 
The library funcitons that we used within this project were .add() and this function was a part of the ArrayList implementation
found in snail. Other than possibly the print statements everything else was from the videos posted and or meeting with Kevin. 
The things that I had the most problems with within the snail language is the use of only white text and the fact that 
the auto complete only completes parts of what your typing depending on the character and or funciton. For example, when I'm 
calling if() statements and or creating strings with "" the auto finish does not finish the other half. So if I were to type " and 
hit enter it would not return the other side of the operator and same goes with parens with if and while loops. I also was 
not a fan of a lot of the error messages due to them ebing vague and only being helpful when I misspelled something and or missed a character.